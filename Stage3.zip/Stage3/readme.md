# How to Run final.py

python final.py

Now in Terminal it will ask following values:

-What is the P0 signal level?
What is the G0 signal level?
What is the P1 signal level?
What is the G1 signal level?
What is the P2 signal level?
What is the G2 signal level?
What is the P3 signal level?
What is the G3 signal level?
What is the C carry value?
What is the nmos width?
What is the supply voltage step level?
What is the temperature of operation?

Ouput will be in below format:

The leakage currents are:

Subthreshold current =

Gate Leakage current =
Body Leakage current =

Leakage Power =
